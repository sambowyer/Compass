#!/bin/bash
#
#
#SBATCH --partition=test


# Change into working directory
cd ~/workshop

# Execute code
/bin/hostname

# Pause to give us time to see the job
sleep 60

